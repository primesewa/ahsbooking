// // booking calculator
//
// // select data fetch
const tab1Btn = document.getElementById("tab1Btn");
const tab2Btn = document.getElementById("tab2Btn");
const tab3Btn = document.getElementById("tab3Btn");

const radioButtons = document.querySelectorAll('input[name="day"]');
const checkboxes = document.querySelectorAll('input[name="week"]');

// getting input fields
const cleaners = document.getElementById("cleaners");
const choose_hour = document.getElementById("choose_hour");
const choose_time = document.getElementById("choose_time");
const cleaning_type = document.getElementById("cleaning_type");
const choose_date = document.getElementById("choose_date");
const material_no = document.getElementById("material_no");
const material_yes = document.getElementById("material_yes");
const booking_message = document.getElementById("booking_message");

cleaning_type.selectedIndex = -1;

booking_message.addEventListener("change", (e) => {
  document.getElementById("message").value = e.target.value;
});

// Initialize variables
let cleaners_selected = 1;
let hour_selected = 1;
let more_day = 0;
let hour_cost = document.getElementById("1HourCost").value;
let material_cost = 0;

let selectedWeeks = [];

// get the changes data form middle button select user click
radioButtons.forEach((button) => {
  button.addEventListener("change", (event) => {
    more_day = event.target.value;

    updateSelectedDay(more_day);
    document.getElementById("days").value = more_day;
    calculator(cleaners_selected, hour_selected, hour_cost, more_day);
  });
});
// changed updaged value form check box
checkboxes.forEach((checkbox) => {
  checkbox.addEventListener("change", (event) => {
    if (event.target.checked) {
      selectedWeeks.push(event.target.value);
    } else {
      selectedWeeks = selectedWeeks.filter((day) => day !== event.target.value);
    }
    // document.getElementById('show_week').innerHTML = selectedWeeks.join(', ');
    updateSelectedWeeks(selectedWeeks);
    more_day = selectedWeeks.length;

    calculator(cleaners_selected, hour_selected, hour_cost, more_day);
  });
});

//first button active and  hide other button and reset selected
tab1Btn.addEventListener("click", () => {
  radioButtons.forEach((button) => {
    button.checked = false;
    updateSelectedDay();
  });

  checkboxes.forEach((checkbox) => {
    checkbox.checked = false;
    updateSelectedWeeks((checkbox.checked = false));
  });
  document.getElementById("cleaners").selectedIndex = -1;
  document.getElementById("choose_hour").selectedIndex = -1;
  calculator(0, 0, 0);
});

// middle button active and hide the Weeks button and reset weeks checkbox
tab2Btn.addEventListener("click", () => {
  checkboxes.forEach((checkbox) => {
    checkbox.checked = false;
    updateSelectedWeeks((checkbox.checked = false));
  });
  document.getElementById("cleaners").selectedIndex = -1;
  document.getElementById("choose_hour").selectedIndex = -1;
  calculator(0, 0, 0);
});
//third button active and hide the middle button and reset radio input
tab3Btn.addEventListener("click", () => {
  radioButtons.forEach((button) => {
    button.checked = false;
    updateSelectedDay();
  });
  document.getElementById("cleaners").selectedIndex = -1;
  document.getElementById("choose_hour").selectedIndex = -1;
  calculator(0, 0, 0);
});

// update the updated or selected days in summary
function updateSelectedDay(day) {
  const showDayContainer = document.getElementById("dayContainer");
  if (day) {
    showDayContainer.style.display = "grid";
    showDayContainer.classList.add("slide-in");
    document.getElementById("show_day").innerHTML = day;
  } else {
    showDayContainer.style.display = "none";
  }
}
//
// update week function to the summary
function updateSelectedWeeks(weeks) {
  const showWeekContainer = document.getElementById("weekContainer");
  if (weeks.length > 0) {
    showWeekContainer.style.display = "grid";
    showWeekContainer.classList.add("slide-in");
    document.getElementById("show_week").innerHTML = weeks.join(", ");
    document.getElementById("days").value = weeks.join(", ");
  } else {
    showWeekContainer.style.display = "none";
  }
}

//
//
//

// show the button text in summary for type booking
document.getElementById("booking_type_show").innerHTML = tab1Btn.innerText;
document.getElementById("book_type").value = tab1Btn.innerText;
tab1Btn.addEventListener("click", () => {
  document.getElementById("booking_type_show").innerHTML = tab1Btn.innerText;
  document.getElementById("book_type").value = tab1Btn.innerText;
});

// on click btn show the input field and hide other tab field
tab2Btn.addEventListener("click", () => {
  document.getElementById("booking_type_show").innerHTML = tab2Btn.innerText;
  document.getElementById("book_type").value = tab2Btn.innerText;
  document.getElementById("tab2").classList.remove("hidden");
  document.getElementById("tab3").classList.add("hidden");
});

// on click btn show the input field and hide other tab field
tab3Btn.addEventListener("click", () => {
  document.getElementById("booking_type_show").innerHTML = tab3Btn.innerText;
  document.getElementById("book_type").value = tab3Btn.innerText;
  document.getElementById("tab3").classList.remove("hidden");
  document.getElementById("tab2").classList.add("hidden");
});

var getCleaner = document.getElementById("cleaners").value;

cleaners_selected = getCleaner;
document.getElementById("cleaners_show").innerHTML = getCleaner;

calculator(cleaners_selected, hour_selected, hour_cost, more_day);

// show cleaners in summary form input field user selected and update value in calculator function
cleaners.addEventListener("change", (e) => {
  cleaners_selected = e.target.value;
  document.getElementById("cleaners_show").innerHTML = e.target.value;
  document.getElementById("number_cleaner").value = e.target.value;
  calculator(cleaners_selected, hour_selected, hour_cost, more_day);
});

var getHours = document.getElementById("cleaners").value;

hour_selected = getHours;
document.getElementById("hour_show").innerHTML = getHours;

calculator(cleaners_selected, hour_selected, hour_cost, more_day);

// show hours in summary form input field user selected and update value in calculator function
// hour and material cost need to calculate so this changed value pass to hour material

choose_hour.addEventListener("change", (e) => {
  hour_cost = e.target.value;
  hour_selected = e.target.options[e.target.selectedIndex].innerText;

  document.getElementById("hour_show").innerHTML = hour_selected;
  document.getElementById("hours").value = hour_selected;

  calculator(cleaners_selected, hour_selected, hour_cost, more_day);
});

// this function used for calculate hour with material cost
// this hour_material hours getting hour form  choose hour change event
// material cost is material_yes input value and getting form there
function hour_material(totalHourCost, hour_selected) {
  // let cost = material_yes.value;
  // material_cost = cost * hour_selected
  // console.log(material_cost);
  //
  // document.getElementById('cleaning_material_show').innerHTML = material_cost;
  //
  // // calculator (cleaners_selected, totalHourCost, more_day, material_cost);
}

// show time in summary form input field user selected and update value in calculator function
choose_time.addEventListener("change", (e) => {
  let time_selected = e.target.value;
  document.getElementById("show_time").innerHTML = time_selected;
  document.getElementById("service_time").value = time_selected;
});

// show cleaning type in summary form input field user selected and update value in calculator function
cleaning_type.addEventListener("change", (e) => {
  document.getElementById("cleaning_type_show").innerHTML = e.target.value;
  document.getElementById("service").value = e.target.value;
});
choose_date.addEventListener("change", (e) => {
  document.getElementById("date_show").innerHTML = e.target.value;
  document.getElementById("date").value = e.target.value;
});
// show the material cost if need material and info in summary by removing hidden class
material_yes.addEventListener("click", () => {
  document.getElementById("material_container").classList.remove("hidden");
  if (material_yes.checked) {
    document.getElementById("materials_need").value = "Yes";
  }

  calculator(cleaners_selected, hour_selected, hour_cost, more_day);
});
material_no.addEventListener("click", () => {
  if (material_no.checked) {
    document.getElementById("materials_need").value = "No";
  }
  calculator(cleaners_selected, hour_selected, hour_cost, more_day);
  document.getElementById("material_container").classList.add("hidden");
});

let number_cleaner = document.getElementById("cleaners_show").innerText;
let number_hours = document.getElementById("hour_show").innerText;

let number_week = document.getElementById("show_week").innerText;
let material_cost_with_hours = document.getElementById(
  "cleaning_material_show"
).innerText;
let discount_amount = document.getElementById("discount_show").innerText;

let discountCode;

window.discountLoad = function () {
  // function body
  calculator(cleaners_selected, hour_selected, hour_cost, more_day);
  discountCode = document.getElementById("discount").value;
};
// document.getElementById('total_show').innerHTML = number_days;
function calculator(cleaners_selected, hour_selected, hour_cost, more_day) {
  let total_cleaner = parseFloat(cleaners_selected);
  let hours = parseFloat(hour_selected);
  let cost_hours = parseFloat(hour_cost);
  let more_days = parseFloat(more_day);
  let material_hour_cost = parseFloat(material_yes.value);

  let total_cleaner_hour = cost_hours * total_cleaner;

  let total = total_cleaner_hour;
  let grandTotal;

  if (material_yes.checked) {
    let total_hours = total_cleaner * hours;
    let total_material_cost = total_hours * material_hour_cost;
    document.getElementById("cleaning_material_show").innerHTML =
      total_material_cost;
    document.getElementById("materials_cost").value = total_material_cost;
    total = total + total_material_cost;

    if (more_day) {
      total = total * more_day;
    }
  } else {
    if (more_day) {
      total = total * more_day;
    }
  }

  document.getElementById("total_show").innerHTML = total;

  var offerInput = document.getElementById("discount").value;

  if (offerInput) {
    if (discountName === discountCode) {
      var grandTotalDiscount = parseFloat(total) - parseFloat(discount);

      document.getElementById("discount_amt").value = discount;
      document.getElementById("discount_show").innerHTML = "-" + discount;
      document.getElementById("grand_total_show").innerHTML =
        grandTotalDiscount;
      document.getElementById("total_amt").value = grandTotalDiscount;
      document.getElementById("discount_submit").classList.remove("bg-primary");
      document.getElementById("discount_submit").classList.add("bg-green-600");
    } else {
      // alert('This Offer not exits or Expired');
      document.getElementById("discount_show").innerHTML = "0";
      // grandTotal = total;
      document.getElementById("discount_submit").classList.add("bg-primary");
      grandTotal = total;
      document.getElementById("grand_total_show").innerHTML = grandTotal;
      document.getElementById("total_amt").value = grandTotal;
    }
  } else {
    grandTotal = total;
    document.getElementById("grand_total_show").innerHTML = grandTotal;
    document.getElementById("total_amt").value = grandTotal;
  }
}
