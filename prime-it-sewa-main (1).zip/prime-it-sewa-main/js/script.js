const swiper = new Swiper(".hero-slider", {
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
    renderBullet: function (index, className) {
      return '<span class="' + className + '">' + "0" + (index + 1) + "</span>";
    },
  },
  loop: true,

  navigation: {
    nextEl: ".swiper-button-next-hero",
    prevEl: ".swiper-button-prev-hero",
  },

  scrollbar: {
    el: ".swiper-scrollbar",
  },
});

const testimonialswiper = new Swiper(".testimonial-slider", {
  pagination: {
    el: ".testimonial-slider-pagination",
    clickable: true,
  },
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
  slidesPerView: 3,
  spaceBetween: 10,
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  breakpoints: {
    100: {
      slidesPerView: 1,
    },
    480: {
      spaceBetween: 20,
      slidesPerView: 1,
    },
    680: {
      slidesPerView: 2,
      spaceBetween: 20,
    },
    1024: {
      slidesPerView: 3,
    },
  },
});
const clientsswiper = new Swiper(".clients-slider", {
  pagination: {
    el: ".clients-slider-pagination",
    clickable: true,
  },
  slidesPerView: 5,
  autoplay: {
    delay: 2500,
    disableOnInteraction: false,
  },
  spaceBetween: 30,
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
  breakpoints: {
    100: {
      slidesPerView: 2,
    },
    480: {
      slidesPerView: 3,
    },
    680: {
      slidesPerView: 4,
    },
    1024: {
      slidesPerView: 5,
    },
  },
});

$(document).ready(function () {
  $(".mobile-ham").click(function () {
    $(".header-menu ").addClass("mobile-menu");
  });
  $(".close").click(function () {
    $(".header-menu ").removeClass("mobile-menu");
  });
  $(".search-btn").click(function () {
    $(".search-box-wrapper").addClass("search-active");
  });
  $(".close-search").click(function () {
    $(".search-box-wrapper").removeClass("search-active");
  });

  // Function to run when clicking on the backdrop
  function handleClickOnBackdrop() {
    $(".search-box-wrapper").removeClass("search-active");
  }

  // Event listener for clicking on the backdrop
  $(".search-box-wrapper").on("click", function (event) {
    // Check if the click target is the backdrop itself
    if ($(event.target).hasClass("search-box-wrapper")) {
      // Call the function to handle the click on the backdrop
      handleClickOnBackdrop();
    }
  });

  $("#datepicker").datepicker();

  $(".timepicker").timepicker({
    timeFormat: "h:mm p",
    interval: 60,
    minTime: "10",
    maxTime: "6:00pm",
    defaultTime: "11",
    startTime: "10:00",
    dynamic: false,
    dropdown: true,
    scrollbar: true,
  });

  $(function () {
    $("#tabs").tabs();
  });
  $(function () {
    $("#accordion-menu").accordion();
  });

  $(".accordion ul").hide();
  $(".accordion .accordion-menu-header").click(function () {
    $(this)
      .next("ul")
      .slideToggle("fast")
      .siblings("ul:visible")
      .slideUp("slow");
    $(this).toggleClass("active");
    $(this).siblings(".accordion-menu-header").removeClass("active");
  });
});

// breakpoint where swiper will be destroyed
// and switches to a dual-column layout
const breakpoint = window.matchMedia("(max-width:460px)");
// keep track of swiper instances to destroy later
let serviceswiper;
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////
const breakpointChecker = function () {
  // if larger viewport and multi-row layout needed
  if (breakpoint.matches === true) {
    // clean up old instances and inline styles when available
    if (serviceswiper !== undefined) serviceswiper.destroy(true, true);
    // or/and do nothing
    return;
    // else if a small viewport and single column layout needed
  } else if (breakpoint.matches === false) {
    // fire small viewport version of swiper
    return enableSwiper();
  }
};

const enableSwiper = function () {
  serviceswiper = new Swiper(".service-slider", {
    pagination: {
      el: ".service-swiper-pagination",
      clickable: true,
    },
    slidesPerView: 4,
    // spaceBetween: 50,
    navigation: {
      nextEl: ".swiper-button-next-services",
      prevEl: ".swiper-button-prev-services",
    },
    loop: true,
    breakpoints: {
      100: {
        slidesPerView: 1,
      },
      480: {
        spaceBetween: 20,
        slidesPerView: 2,
        swiper: "disable",
      },
      680: {
        slidesPerView: 3,
        spaceBetween: 20,
      },
      1024: {
        slidesPerView: 4,
      },
    },
  });
};

// keep an eye on viewport size changes
breakpoint.addListener(breakpointChecker);
// kickstart
breakpointChecker();

const menu = document.querySelector(".menu");
const menuSection = menu.querySelector(".menu-section");
const menuArrow = menu.querySelector(".menu-mobile-arrow");
const menuClosed = menu.querySelector(".menu-mobile-close");
const menuTrigger = document.querySelector(".menu-mobile-trigger");
const menuOverlay = document.querySelector(".overlay");
let subMenu;
menuSection.addEventListener("click", (e) => {
  if (!menu.classList.contains("active")) {
    return;
  }
  if (e.target.closest(".menu-item-has-children")) {
    const hasChildren = e.target.closest(".menu-item-has-children");
    showSubMenu(hasChildren);
  }
});
menuArrow.addEventListener("click", () => {
  hideSubMenu();
});
menuTrigger.addEventListener("click", () => {
  toggleMenu();
});
menuClosed.addEventListener("click", () => {
  toggleMenu();
});
menuOverlay.addEventListener("click", () => {
  toggleMenu();
});
function toggleMenu() {
  menu.classList.toggle("active");
  menuOverlay.classList.toggle("active");
}
function showSubMenu(hasChildren) {
  subMenu = hasChildren.querySelector(".menu-subs");
  subMenu.classList.add("active");
  subMenu.style.animation = "slideLeft 0.5s ease forwards";
  const menuTitle =
    hasChildren.querySelector("img").parentNode.childNodes[0].textContent;
  menu.querySelector("#menu-mobile-title").innerHTML = menuTitle;
  menu.querySelector(".menu-mobile-header").classList.add("active");
}
function hideSubMenu() {
  subMenu.style.animation = "slideRight 0.5s ease forwards";
  setTimeout(() => {
    subMenu.classList.remove("active");
  }, 300);
  menu.querySelector("#menu-mobile-title").innerHTML = "";
  menu.querySelector(".menu-mobile-header").classList.remove("active");
}
window.onresize = function () {
  if (this.innerWidth > 991) {
    if (menu.classList.contains("active")) {
      toggleMenu();
    }
  }
};
