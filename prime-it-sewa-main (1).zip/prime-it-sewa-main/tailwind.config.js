/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        primary: "#0162b3",
        secondary: "#eca725",
        darkBlue: "#051135",
        testColor: "#2b3537",
        textColor: "#2b3537",
        bgColor: "#f3f4f6",
      },
      fontFamily: {
        poppins: ["Poppins"],
      },
      fontSize: {
        medium: "14px",
      },
      boxShadow: {
        blue: "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
        card: "rgba(149, 157, 165, 0.2) 0px 8px 24px",
      },
      padding: {
        button: "10px 30px",
      },
      gridTemplateColumns: {
        footer: "1.5fr 1fr 1fr 1fr ",
      },
    },
  },
  plugins: [],
};
